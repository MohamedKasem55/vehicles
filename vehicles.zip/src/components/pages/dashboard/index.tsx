import DashboardCard, {
  IDashboardCard,
} from "@/components/molecules/dashboardCard";
import React from "react";
import Suitcase from "../../../assets/svg/suitcase.svg?react";
import Inbox from "../../../assets/svg/inbox.svg?react";
import Search from "../../../assets/svg/search.svg?react";
import Setting from "../../../assets/svg/setting.svg?react";
import Shield from "../../../assets/svg/shield.svg?react";

function Dashboard() {
  const dashboardCards: Partial<IDashboardCard>[] = [
    { id: "services", text: "الخدمات", icon: Suitcase },
    { id: "inbox", text: "صندوق المتابعة", icon: Inbox },
    { id: "information", text: "الإستعلامات", icon: Search },
    { id: "setting", text: "إعدادات النظام", icon: Setting },
    { id: "authority", text: "الصلاحيات", icon: Shield },
  ];
  const dashboardCardClickHandler = (id: string) => {};
  return (
    <div className="p-10 flex flex-col justify-center items-center flex-1 gap-3">
      <div className="text-[#104731] font-bold text-center leading-10 tracking-normal align-middle text-[30.6px]">مرحبا بك في نظام المركبات</div>
      <div className="text-[#6B7280] font-normal text-center leading-7 tracking-normal align-middle text-[15.3px]">
       اختر الخدمة التي تريدالوصول إليها 
       </div>
      <div className="flex flex-row flex-wrap justify-center items-center gap-5 w-[60%]">

      {dashboardCards.map((dashboardCard: Partial<IDashboardCard>) => (
        <DashboardCard
        icon={dashboardCard.icon}
        id={dashboardCard.id}
        text={dashboardCard.text}
        clickHandler={dashboardCardClickHandler}
        />
      ))}
      </div>
    </div>
  );
}

export default Dashboard;
