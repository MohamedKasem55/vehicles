import IconWrapper from "@/components/atoms/iconWrapper";
import React from "react";
export interface IDashboardCard {
  id: string;
  text: string;
  icon: React.FC<React.SVGProps<SVGSVGElement>>;
  clickHandler: (id: string) => void;
}
function DashboardCard({ icon: Icon, id, text, clickHandler }: IDashboardCard) {
  return (
    <div
      key={id}
      className="bg-[#3D5A50] w-72 h-48 opacity-100 rounded-2xl flex flex-row justify-center items-center cursor-pointer hover:opacity-70"
      onClick={() => clickHandler(id)}
    >
      <div className="flex flex-col items-center justify-center gap-3">
        <IconWrapper
          icon={Icon}
          customClasses={"bg-[#506A62] w-20 h-20 rounded-[16px]"}
        />
        <span className="font-bold text-center leading-7 tracking-normal align-middle text-[17px] text-white">
          {text}
        </span>
      </div>
    </div>
  );
}

export default DashboardCard;
