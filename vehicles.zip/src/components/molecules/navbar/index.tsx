import React from "react";
import Logo from "../../../assets/svg/logo.svg?react";
import NavbarButton, {
  INavbarButton,
} from "@/components/molecules/navbarButton/navbarButton";
import Dashboard from "../../../assets/svg/dashboard.svg?react";
import Logout from "../../../assets/svg/logout.svg?react";
import Profile from "../../../assets/svg/profile.svg?react";
import { useLocation } from "react-router-dom";
function Navbar() {

  
  const location = useLocation()
  const NavbarButtons: Partial<INavbarButton>[] = [
    { id: "logout", text: "تسجيل الخروج", icon: Logout },
    { id: "profile", text: "محمد خالد", icon: Profile },
    ...( location.pathname !== '/dashboard' ? [{ id: "dashboard", text: "الرئيسية", icon: Dashboard }] : []) ,
  ];

  const navbarButtonClickHandler = (id: string) => {

  };
  return (
    <div className="flex flex-row items-center justify-between pl-20">
      <div className="flex flex-row items-center justify-between gap-8">

      {NavbarButtons.map((navbarButton: INavbarButton,index:number) => (
        <>
        <NavbarButton
        icon={navbarButton.icon}
        text={navbarButton.text}
        clickHandler={navbarButtonClickHandler}
        />
        {(index !==NavbarButtons.length-1) && <span className="text-[#D1D5DB]">|</span>}
        </>
      ))}
      </div>
      <Logo className="w-20 h-15 fill-blue-500" />
    </div>
  );
}

export default Navbar;
