import React from 'react'

function IconWrapper({icon:Icon,customClasses}) {
  return (
      <div className={`${customClasses} flex flex-row items-center justify-center`}>
        <Icon/>
      </div>
  )
}

export default IconWrapper