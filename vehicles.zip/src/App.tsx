import { Navigate, Route, Routes } from "react-router-dom";
import "./index.css";
import Footer from "./components/molecules/footer";
import Navbar from "./components/molecules/navbar";
import Login from "./components/pages/login";
import Dashboard from "./components/pages/dashboard";

function App() {
  return (
    <>
      <div className="flex flex-col min-h-screen w-full">
        <Navbar />
        <main className="flex-1 flex flex-col">
          <Routes>
            <Route index element={<Navigate to="/login" replace />} />
            <Route path="/login" element={<Login />} />
            <Route path="/dashboard" element={<Dashboard />} />
          </Routes>
        </main>
        <Footer />
      </div>
    </>
  );
}

export default App;
